import 'package:quiz_app/models/quiz_question.dart';

const questions = [
  QuizQuestion("What brand is AMG associated with?",[ "Mercedes","BMW","Audi","VW"]),
  QuizQuestion("What brand is M associated with?", ["BMW", "Mercedes","Audi", "VW"]),
  QuizQuestion("Which company owns Rolls-Royce?", ["BMW", "Mercedes", "VW"]),
  QuizQuestion("Which company owns Lamboghini?", ["Audi", "Porsche", "VW", "BMW"]),
  QuizQuestion("The C63 belongs to which company?", ["Mercedes","BMW","Honda", "Audi"]),
];